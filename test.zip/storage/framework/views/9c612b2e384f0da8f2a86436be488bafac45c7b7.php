
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ট্রেড লাইসেন্স</title>
    <link href="<?php echo e(asset('trad-certificate/tradCertificate.css')); ?>" rel="stylesheet" type="text/css"/>
    <style>
.bg-img {
    background-image: url("<?php echo e(('/page-bg/bg_img_' . $services->union_id . '.jpeg')); ?>") !important;
    background-repeat: no-repeat !important;
    background-position: center !important;
    background-size: 70% !important;
}

</style>
</head>

<body>

    <section class="trad bg-img">

        <section class="trad-section">



            <div class="trad-section-right">
                <div class="trad-section-right-header">
                    <div class="trad-section-right-header-title">
                        <img src="<?php echo e(asset('trad-certificate/Images/trad-ogo.jpg')); ?>" alt="#" />
                        <h1><?php echo e($services->union_name); ?></h1>
                    </div>

                    <h3>ডাকঘরঃ <?php echo e($services->post_office); ?>, উপজেলাঃ <?php echo e($services->upazila_name); ?>, জেলাঃ <?php echo e($services->district_name); ?></h3>
                    <h4>horipurup.rajshahi.gov.bd</h4>
                    <h2>ট্রেড লাইসেন্স (ব্যবসার ছাড়পত্র)</h2>

                    <div class="trad-section-right-header-input">
                        <p>বহি নং- ০৭৮</p>
                        <p>অর্থ বৎসরঃ <span><?php echo e($services->trade_current_year); ?></span></p>
                        <p>লাইসেন্স নম্বরঃ <span><?php echo e($services->trade_license_no); ?></span></p>
                    </div>

                    <div class="trad-section-right-header-input-input">
                        <p>ক্রমিক নং-<?php echo e($services->trade_id); ?></p>
                        <p>তারিখ <span><?php echo e($date); ?></span></p>
                    </div>
                </div>



                <div class="trad-section-right-discription">
                    <p>ব্যবসা প্রতিষ্ঠানের নাম <span><?php echo e($services->institute_name); ?></span> লাইসেন্স ধারীর নাম <span><?php echo e($services->applicant_name); ?></span> ভোটার আইডি নং <span><?php echo e($services->applicant_nid); ?></span> পিতা/স্বামী নাম <span><?php echo e($services->applicant_f_name); ?></span> মাতা <span><?php echo e($services->applicant_m_name); ?></span> স্থায়ী ঠিকানাঃ <?php echo e($services->trade_permanent_addess); ?> গ্রাম/মহল্লাঃ <span><?php echo e($services->village_name); ?></span>                        ওয়ার্ড নং <span><?php echo e($services->ward_no); ?></span> ডাকঘর <span><?php echo e($services->post_office); ?></span> থানা/উপজেলা <span>সাতুরিয়া</span> জেলা <span><?php echo e($services->district_name); ?></span> ব্যবসার স্থান <span><?php echo e($services->trade_present_addess); ?></span>  পেশার ধরন (ব্যবসা) <span><?php echo e($services->business_type); ?></span>

                        লাইসেন্স ফি প্রদানের পরিমাণ টাকা <span><?php echo e($services->trade_fee); ?></span>
                        (কথায়<span><?php echo e($services->trade_fee_des); ?></span>) ১৫% ভ্যাট টাকা <span><?php echo e($services->trade_vat); ?></span>

                          মোট <span><?php echo e(number_format(($services->trade_vat + $services->trade_fee), 2, '.', '')); ?></span> টাকা
                        প্রাপ্ত হয়ে তার


                        ব্যবসা/বৃত্তি/পেশা
                        <span><?php echo e($services->business_type); ?></span> চালিয়ে যাবার জন্য লাইসেন্স প্রদান করা হলো। লাইসেন্স এর মেয়াদ <?php echo e($services->expire_date); ?> পর্যন্ত।</p>
                    <div></div>
                </div>


                <div class="trad-section-right-footer">
                    <p>কোষাধ্যক্ষ/সেক্রেটারী</p>

                    <p class="sign-img">
                        <img src="<?php echo e(Request::root()); ?>/<?php echo e($services->sign); ?>" width="100" style="display: block"/>

                        চেয়ারম্যান

                    </p>
                </div>
                <div  class="instructions">
                    <h3>নির্দেশনাবলী:</h3>

                    <p>
                        ১)
                        সার্টিফিকেট টি online  এ verification এর জন্য পেজ https//euptax.com এ আসুন এবং সনদ নং ও মোবাইল নাম্বার দিয়ে অনুসন্ধান করুন | অথবা আপনার smart  phone  থেকে QR code টি Scan করুন |
                    </p>
                    <p>
                        ২)
                        যেকোনো ধরণের তথ্য নেয়ার জন্য ফোন করুন অথবা ইমেইল করুন |
                    </p>

                </div>

            </div>
        </section>


        <section class="tread-footer">
            <p>* সময়মত ইউপি কর পরিশোধ করুন জন্ম * নিবন্ধন করুন * বল্য বিবাহ প্রতিরোধ করুন। * গাছ লাগান পরিবেশ বাঁচান।</p>
        </section>
    </section>

</body>

</html>
<?php /**PATH /home/rifat/taxlaravel/resources/views/services/tradCertificate.blade.php ENDPATH**/ ?>